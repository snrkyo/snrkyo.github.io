# basic
A interpreter for untyped lambda calculli
